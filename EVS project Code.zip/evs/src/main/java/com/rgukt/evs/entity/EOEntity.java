package com.rgukt.evs.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class EOEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int eoId;
	private int electionId;
	private String eoName;
	private String eoEmail;
	private String eoPassword;
	public int getEoId() {
		return eoId;
	}
	public void setEoId(int eoId) {
		this.eoId = eoId;
	}
	public int getElectionId() {
		return electionId;
	}
	public void setElectionId(int electionId) {
		this.electionId = electionId;
	}
	public String getEoName() {
		return eoName;
	}
	public void setEoName(String eoName) {
		this.eoName = eoName;
	}
	public String getEoEmail() {
		return eoEmail;
	}
	public void setEoEmail(String eoEmail) {
		this.eoEmail = eoEmail;
	}
	public String getEoPassword() {
		return eoPassword;
	}
	public void setEoPassword(String eoPassword) {
		this.eoPassword = eoPassword;
	}
	
	
}
